
# How to build

install npm and typescript
 
run commands

```
npm install
tsc
```

Open index.html