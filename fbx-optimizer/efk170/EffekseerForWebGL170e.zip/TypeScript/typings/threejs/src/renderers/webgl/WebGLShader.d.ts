export function WebGLShader(gl: WebGLRenderingContext, type: string, string: string): WebGLShader;
